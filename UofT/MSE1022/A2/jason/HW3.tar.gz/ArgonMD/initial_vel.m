function p = initial_vel(N,p)

p = rand(N,3); % random velocities from 0 to 1
p = 2*p - 1.0;


