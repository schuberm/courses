function kinetic=atomeye(name,a,t,L,ident_letter,m,x,p)
%output atomeye format

%IN PROGRESS