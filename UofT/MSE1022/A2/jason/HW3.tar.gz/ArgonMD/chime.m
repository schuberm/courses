function kinetic=chime(time,x,indet_letter)
%output CHIME format

%IN PROGRESS