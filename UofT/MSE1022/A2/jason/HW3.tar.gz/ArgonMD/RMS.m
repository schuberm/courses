function xrms = mean_square(x,x_0,N);

for i=1:N
    for k=1:3
        xrms(i,1) = sqrt( 



