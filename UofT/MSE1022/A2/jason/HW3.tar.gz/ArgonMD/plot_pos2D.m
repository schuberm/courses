function plot_pos2D(x,L)

plot(x(:,1),x(:,2),'.')
axis([0 L(1,1) 0 L(1,2)])
